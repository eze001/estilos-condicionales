<template>
  <div id="lugar">
      <p>{{nombrelugar}}</p>
      <p>{{infolugar}}</p>
      <button v-on:click="funcion(nombrelugar)">Encontrar oro</button>  
  </div>
</template>

<script>

import Almacen from '@/almacen';

export default {
  name: 'lugar',
  props: {
    nombrelugar: String,
    infolugar: String,
  },
  methods:{
      funcion:function(nombrel){
          Almacen.incrementaroro(nombrel);
      }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->

<style scoped>
    #lugar{
        width:200px;
        height:130px;
        outline:3px solid black;
        display:inline-block;
        margin:10px;
        padding:10px;
    }
    p{
        display:block;
        margin:10px;
    }
    button{
        display:block;
        margin:10px;
    }
</style>